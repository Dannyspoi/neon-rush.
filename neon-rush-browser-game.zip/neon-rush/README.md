# NEON RUSH

A self-contained browser arcade game. No build tools, libraries, or server code required.

## Play locally
Open `index.html` in a modern browser.

## Publish free with GitHub Pages
1. Sign in to GitHub and create a **new public repository** (for example, `neon-rush`).
2. Upload `index.html` from this folder to the repository's top level.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)`, then save.
6. After GitHub finishes publishing, your game will be available at:
   `https://YOUR-USERNAME.github.io/neon-rush/`

The game saves a personal best in the player's browser. The share button uses the browser's native share sheet where available, or copies a challenge message. A global online leaderboard would require a separate backend.
